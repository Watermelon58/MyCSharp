﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5
{
    class Order:IComparable
    {
        public int OrderID { get; set; }
        public string ClientName { get; set; }
        public int ClientID { get; set; }
        public DateTime OrderDate { get; set; }

        public List<OrderItem> orderItems = new List<OrderItem>();

        public double TotalPrice
        {
            get
            {
                double price = 0.0;
                foreach(OrderItem item in orderItems)
                {
                    price += item.ItemTotalPrice;
                }
                return price;
            }
        }
        public Order(int OrderID,string ClientName,int ClientID,DateTime OrderDate)
        {
            this.OrderID = OrderID;
            this.ClientName = ClientName;
            this.ClientID = ClientID;
            this.OrderDate = OrderDate;
        }

        public int CompareTo(object obj)
        {
            Order order = obj as Order;
            if(order==null)
                throw new System.ArgumentException();
            return this.OrderID.CompareTo(order.OrderID);
        }


        public override bool Equals(object obj)
        {
            Order order = obj as Order;
            return order != null && order.OrderID == OrderID;
        }

        public override int GetHashCode()
        {
            return OrderID.GetHashCode();
        }

        public override string ToString()
        {
            return "OrderID：" + OrderID + ";ClientName:" + ClientName
                + ";ClientID:" + ClientID + ";OrderDate:" + OrderDate;
        }
        public string ItemToString()
        {
            string itemInfo = null;
            foreach(OrderItem i in orderItems)
            {
                itemInfo+=i.ToString()+";     ";
            }
            return itemInfo;
        }
    }
}
