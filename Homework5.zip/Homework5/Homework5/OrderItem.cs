﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5
{
    class OrderItem
    {
        public int ItemID { get; set; }
        public string ProductName { get; set; }
        public int ProductQuantity { get; set; }
        public double UnitPrice { get; set; }
        public double ItemTotalPrice
        {
            get
            {
                return UnitPrice * ProductQuantity;
            }
        }

        public OrderItem(int ItemID,string ProductName,double UnitPrice,int ProductQuantity)
        {
            this.ItemID = ItemID;
            this.ProductName = ProductName;
            this.UnitPrice = UnitPrice;
            this.ProductQuantity = ProductQuantity;
        }

        public override bool Equals(object obj)
        {
            OrderItem orderItem = obj as OrderItem;
            return orderItem != null && orderItem.ItemID == ItemID;
        }

        public override int GetHashCode()
        {
            return ItemID.GetHashCode();
        }

        public override string ToString()
        {
            return "ProductName:" + ProductName + ";UnitPrice:" + UnitPrice + ";ProductQuantity:" + ProductQuantity;
        }
    }
}
