﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5
{
    class OrderService
    {
        private List<Order> orders = new List<Order>();

        public void AddOrder(int OrderID,string ClientName,int ClientID,DateTime OrderDate)
        {
            var newOrder = new Order(OrderID, ClientName, ClientID, OrderDate);
            foreach(Order order in orders)
            {
                if (newOrder.Equals(order))
                    throw new Exception("Same order!");
                orders.Add(newOrder);
            }
        }

        public void AddOrder(Order order)
        {
            orders.Add(order);
        }

        public void DeleteOrderByID(int OrderID)
        {
            var p = GetOrderByID(OrderID);
            if (p != null)
            {
                orders.Remove(p);
                return;
            }
            throw new Exception("OrderID not found!");
        }

        public void DeleteOrder(Order order)
        {
            orders.Remove(order);
        }

        public void UpDateOrder(Order order, int OrderID, string ClientName, int ClientID, DateTime OrderDate)
        {
            var theOrder = new Order(OrderID, ClientName, ClientID, OrderDate);
            if (theOrder.Equals(order))
                throw new Exception("Nothing to change!");
            order=theOrder;
        }

        public Order GetOrderByID(int OrderID)
        {
            var order = from o in orders
                        where o.OrderID == OrderID
                        select o;
            return (Order)order;
        }

        public Order GetOrderByClientName(string ClientName)
        {
            var order = from o in orders
                          where o.ClientName == ClientName
                          select o;
            return (Order)order;
        }

        public void GetOrderByProductName(string ProductName,out List<Order> outOrders)
        {
            outOrders = null;
            foreach (Order order in orders)
            {
                 foreach(OrderItem orderItem in order.orderItems)
                 {
                    if (orderItem.ProductName == ProductName)
                        outOrders.Add(order);
                 }
            }
            outOrders.Sort((o1,o2)=>(int)(o1.TotalPrice-o2.TotalPrice));
        }

        public void Sort(List<Order> listOrders)
        {
            listOrders.Sort();
        }

        public void SortByPrice(List<Order> listOrders)
        {
            listOrders.Sort((o1, o2) => (int)(o1.TotalPrice - o2.TotalPrice));
        }
    }
}
