﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5
{
    class Program
    {
        static void Main(string[] args)
        {
            //实例化订单项目
            OrderItem orderItem1 = new OrderItem(123, "薯片", 5.8, 2);
            Console.WriteLine(orderItem1);
            OrderItem orderItem2 = new OrderItem(135, "酸奶", 2.7, 4);
            Console.WriteLine(orderItem2);
            OrderItem orderItem3 = new OrderItem(054, "奶茶", 10.0, 1);
            Console.WriteLine(orderItem3);
            //实例化订单
            Order order1 = new Order(000, "XiaXin", 20000508, DateTime.Today.AddDays(-1));
            Order order2 = new Order(001, "WangTian", 20000327, DateTime.Today);
            //实例化订单服务
            OrderService orderService = new OrderService();
            //服务中添加订单
            orderService.AddOrder(order1);
            orderService.AddOrder(order2);
            //订单中添加项目
            order1.orderItems.Add(orderItem2);
            order1.orderItems.Add(orderItem3);
            Console.WriteLine(order1);
            Console.WriteLine( order1.ItemToString());
            order2.orderItems.Add(orderItem1);
            order2.orderItems.Add(orderItem3);
            Console.WriteLine(order2);
            Console.WriteLine( order2.ItemToString());
            //更改订单
            orderService.UpDateOrder(order2, 003, "WangLeiMin", 20000327, DateTime.Today);
            Console.WriteLine( order2.ToString());
            //查询订单
            //通过id
            Console.WriteLine(orderService.GetOrderByID(000).ToString());
            //通过名称
            List<Order> orders = null;
            orderService.GetOrderByProductName("奶茶",out orders);
            foreach(var o in orders)
                Console.WriteLine(((Order)o).ToString());
        }
    }
}
