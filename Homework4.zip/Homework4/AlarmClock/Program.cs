﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace AlarmClock
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                var clock = new Clock();
                clock.Tick += (sender, arg) => Console.WriteLine(arg.time);
                clock.Alarm += (sender, arg) => Console.WriteLine("Alarming!It's " + arg.time + " now!");
                if (clock.setAlarmTime(2020, 5, 8, 9, 27))
                    clock.Start();
                else
                    Console.WriteLine("Settled time wrong!");
                System.Threading.Thread.Sleep(1000);
            }
        }
    }
    public delegate void StartAlarming(object sender, MyEventArgs args);
    public delegate void TickOnce(object sender, MyEventArgs args);

    public class MyEventArgs
    {
        public DateTime time;
    }
    
    public class Clock
    {
        public event TickOnce Tick;
        public event StartAlarming Alarm;
        private DateTime alarmTime;
        private Timer timer;

        public Clock()
        {
            Tick += (sender, args) => { };
            Alarm += (sender, args) => { };
            timer = new Timer(580.0);
            timer.Elapsed += manageTick;
            timer.Enabled = true;
        }
        public void Start()
        {
            timer.Start();
        }
        public void Stop()
        {
            timer.Stop();
        }

        public bool setAlarmTime(int year,int month,int day,int hour,int minute)
        {
            bool b1 = year >= DateTime.Now.Year;
            bool b2 = month >= 1 && month <= 12;
            bool b3 = day >= 1 && day <= 31;
            bool b4 = hour >= 0 && hour < 24;
            bool b5 = minute >= 0 && minute < 60;
            if (!(b1 && b2 && b3 && b4 && b5))
                return false;
            this.alarmTime = new DateTime(year, month, day, hour, minute, 0);
            return true;
        }

        private void manageTick(object sender, ElapsedEventArgs arg)
        {
            var now = DateTime.Now;
            Tick(this, new MyEventArgs() { time = now });
            if (alarmTime != null && now.Year == alarmTime.Year &&
            now.Month == alarmTime.Month && now.Day == alarmTime.Day &&
            now.Hour == alarmTime.Hour && now.Minute == alarmTime.Minute)
            {
                Alarm(this, new MyEventArgs() { time = now });
            }
        }
    }
}
