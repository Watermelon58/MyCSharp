﻿namespace homework7
{
    partial class treeMaker
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.treePanel = new System.Windows.Forms.Panel();
            this.递归深度 = new System.Windows.Forms.Label();
            this.N = new System.Windows.Forms.TrackBar();
            this.begin = new System.Windows.Forms.Button();
            this.leng = new System.Windows.Forms.TrackBar();
            this.主干长度 = new System.Windows.Forms.Label();
            this.右分支长度比 = new System.Windows.Forms.Label();
            this.左分支长度比 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rightper = new System.Windows.Forms.TrackBar();
            this.leftper = new System.Windows.Forms.TrackBar();
            this.rightth = new System.Windows.Forms.TrackBar();
            this.leftth = new System.Windows.Forms.TrackBar();
            this.btnColor = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.N)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftth)).BeginInit();
            this.SuspendLayout();
            // 
            // treePanel
            // 
            this.treePanel.Location = new System.Drawing.Point(13, 13);
            this.treePanel.Name = "treePanel";
            this.treePanel.Size = new System.Drawing.Size(563, 587);
            this.treePanel.TabIndex = 0;
            // 
            // 递归深度
            // 
            this.递归深度.AutoSize = true;
            this.递归深度.Location = new System.Drawing.Point(600, 13);
            this.递归深度.Name = "递归深度";
            this.递归深度.Size = new System.Drawing.Size(67, 15);
            this.递归深度.TabIndex = 1;
            this.递归深度.Text = "递归深度";
            // 
            // N
            // 
            this.N.Location = new System.Drawing.Point(603, 31);
            this.N.Maximum = 15;
            this.N.Minimum = 1;
            this.N.Name = "N";
            this.N.Size = new System.Drawing.Size(104, 56);
            this.N.TabIndex = 2;
            this.N.Value = 1;
            this.N.Scroll += new System.EventHandler(this.N_Scroll);
            // 
            // begin
            // 
            this.begin.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.begin.Location = new System.Drawing.Point(603, 577);
            this.begin.Name = "begin";
            this.begin.Size = new System.Drawing.Size(104, 23);
            this.begin.TabIndex = 3;
            this.begin.Text = "begin";
            this.begin.UseVisualStyleBackColor = false;
            this.begin.Click += new System.EventHandler(this.begin_Click);
            // 
            // leng
            // 
            this.leng.Location = new System.Drawing.Point(603, 93);
            this.leng.Maximum = 100;
            this.leng.Minimum = 50;
            this.leng.Name = "leng";
            this.leng.Size = new System.Drawing.Size(104, 56);
            this.leng.TabIndex = 4;
            this.leng.Value = 50;
            this.leng.Scroll += new System.EventHandler(this.leng_Scroll);
            // 
            // 主干长度
            // 
            this.主干长度.AutoSize = true;
            this.主干长度.Location = new System.Drawing.Point(603, 72);
            this.主干长度.Name = "主干长度";
            this.主干长度.Size = new System.Drawing.Size(67, 15);
            this.主干长度.TabIndex = 5;
            this.主干长度.Text = "主干长度";
            // 
            // 右分支长度比
            // 
            this.右分支长度比.AutoSize = true;
            this.右分支长度比.Location = new System.Drawing.Point(600, 141);
            this.右分支长度比.Name = "右分支长度比";
            this.右分支长度比.Size = new System.Drawing.Size(97, 15);
            this.右分支长度比.TabIndex = 6;
            this.右分支长度比.Text = "右分支长度比";
            // 
            // 左分支长度比
            // 
            this.左分支长度比.AutoSize = true;
            this.左分支长度比.Location = new System.Drawing.Point(603, 219);
            this.左分支长度比.Name = "左分支长度比";
            this.左分支长度比.Size = new System.Drawing.Size(97, 15);
            this.左分支长度比.TabIndex = 7;
            this.左分支长度比.Text = "左分支长度比";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(600, 300);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "右分支角度";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(603, 378);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "左分支角度";
            // 
            // rightper
            // 
            this.rightper.Location = new System.Drawing.Point(603, 160);
            this.rightper.Maximum = 100;
            this.rightper.Minimum = 50;
            this.rightper.Name = "rightper";
            this.rightper.Size = new System.Drawing.Size(104, 56);
            this.rightper.TabIndex = 10;
            this.rightper.Value = 50;
            this.rightper.Scroll += new System.EventHandler(this.rightper_Scroll);
            // 
            // leftper
            // 
            this.leftper.Location = new System.Drawing.Point(603, 241);
            this.leftper.Maximum = 100;
            this.leftper.Minimum = 50;
            this.leftper.Name = "leftper";
            this.leftper.Size = new System.Drawing.Size(104, 56);
            this.leftper.TabIndex = 11;
            this.leftper.Value = 50;
            this.leftper.Scroll += new System.EventHandler(this.leftper_Scroll);
            // 
            // rightth
            // 
            this.rightth.Location = new System.Drawing.Point(603, 319);
            this.rightth.Maximum = 90;
            this.rightth.Minimum = 1;
            this.rightth.Name = "rightth";
            this.rightth.Size = new System.Drawing.Size(104, 56);
            this.rightth.TabIndex = 12;
            this.rightth.Value = 1;
            this.rightth.Scroll += new System.EventHandler(this.rightth_Scroll);
            // 
            // leftth
            // 
            this.leftth.Location = new System.Drawing.Point(603, 407);
            this.leftth.Maximum = 90;
            this.leftth.Name = "leftth";
            this.leftth.Size = new System.Drawing.Size(104, 56);
            this.leftth.TabIndex = 13;
            this.leftth.Scroll += new System.EventHandler(this.leftth_Scroll);
            // 
            // btnColor
            // 
            this.btnColor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnColor.Location = new System.Drawing.Point(603, 469);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(97, 28);
            this.btnColor.TabIndex = 16;
            this.btnColor.Text = "颜色选择";
            this.btnColor.UseVisualStyleBackColor = false;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnClear.Location = new System.Drawing.Point(603, 524);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(97, 23);
            this.btnClear.TabIndex = 17;
            this.btnClear.Text = "clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // treeMaker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(744, 632);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnColor);
            this.Controls.Add(this.leftth);
            this.Controls.Add(this.rightth);
            this.Controls.Add(this.leftper);
            this.Controls.Add(this.rightper);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.左分支长度比);
            this.Controls.Add(this.右分支长度比);
            this.Controls.Add(this.主干长度);
            this.Controls.Add(this.leng);
            this.Controls.Add(this.begin);
            this.Controls.Add(this.N);
            this.Controls.Add(this.递归深度);
            this.Controls.Add(this.treePanel);
            this.Name = "treeMaker";
            this.Text = "treeMaker";
            ((System.ComponentModel.ISupportInitialize)(this.N)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftth)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel treePanel;
        private System.Windows.Forms.Label 递归深度;
        private System.Windows.Forms.TrackBar N;
        private System.Windows.Forms.Button begin;
        private System.Windows.Forms.TrackBar leng;
        private System.Windows.Forms.Label 主干长度;
        private System.Windows.Forms.Label 右分支长度比;
        private System.Windows.Forms.Label 左分支长度比;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar rightper;
        private System.Windows.Forms.TrackBar leftper;
        private System.Windows.Forms.TrackBar rightth;
        private System.Windows.Forms.TrackBar leftth;
        private System.Windows.Forms.Button btnColor;
        private System.Windows.Forms.Button btnClear;
    }
}

