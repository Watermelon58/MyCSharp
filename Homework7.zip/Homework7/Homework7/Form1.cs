﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homework7
{
    public partial class treeMaker : Form
    {
        public treeMaker()
        {
            InitializeComponent();
        }

        private void begin_Click(object sender, EventArgs e)
        {
            if (graphics == null) graphics = treePanel.CreateGraphics();
            drawCayleyTree(n, treePanel.Width / 2, 400, length, -Math.PI / 2);
        }

        private Graphics graphics;
        int n = 10;
        double length = 100;
        double th1 = 30 * Math.PI / 180;
        double th2 = 20 * Math.PI / 180;
        double per1 = 0.6;
        double per2 = 0.7;

        void drawCayleyTree(int n, double x0, double y0, double leng, double th)
        {
            if (n == 0) return;

            double x1 = x0 + leng * Math.Cos(th);
            double y1 = y0 + leng * Math.Sin(th);

            drawLine(x0, y0, x1, y1);
            ;
            drawCayleyTree(n - 1, x1, y1, leng * per1, th + th1);
            drawCayleyTree(n - 1, x1, y1, leng * per2, th - th2);
        }



        void drawLine(double x0, double y0, double x1, double y1)
        {
            Pen pen = new Pen(this.btnColor.BackColor);
            graphics.DrawLine(pen, (int)x0, (int)y0, (int)x1, (int)y1);
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            using (ColorDialog cdialog = new ColorDialog())
            {
                cdialog.AnyColor = true;
                if (cdialog.ShowDialog() == DialogResult.OK)
                {
                    this.btnColor.BackColor = cdialog.Color;
                }
            }
        }

        private void N_Scroll(object sender, EventArgs e)
        {
            n = N.Value;
        }

        private void leng_Scroll(object sender, EventArgs e)
        {
            length = leng.Value;
        }

        private void rightper_Scroll(object sender, EventArgs e)
        {
            per1 = (double)rightper.Value/100;
        }

        private void leftper_Scroll(object sender, EventArgs e)
        {
            per2 = (double)leftper.Value / 100;
        }

        private void rightth_Scroll(object sender, EventArgs e)
        {
            th1 = rightth.Value * Math.PI / 180;
        }

        private void leftth_Scroll(object sender, EventArgs e)
        {
            th2 = leftth.Value * Math.PI / 180;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.treePanel.Refresh();
        }
    }
}